/*
Program 1 Plan:
include cmath
create a cin double for principal balance named 'principal'
create a cin double for annual percentage interest rate named 'rate'
create a cin int for number of times interest has compounded during one year named 'times_compounded'
create a double variable defined by 'amount = principal*pow(1.0+rate/times_compounded, times_compounded)'
create another double variable to change the entered percentage to decimal form defined by interest_earned = amount-principal
in a cout print the interest rate, times compounded, principal, interest earned, and amount with text labels
run with given tests to confirm the code works

First Program Test 1: (first test didn't match I corrected it by dividing rate/100 in the amount formula)
Principal: $1,000.00
Annual interest rate: 4.25%
Times compounded: 12
results I was supposed to get: Interest Earned: $43.34  Amount in Savings: $1,043.34
results I got: Interest Earned: 43.3377      Amount: 1043.34

First Program Test 2: (matched the first try)
Principal: $12,780.0
Annual interest rate: 3.14%
Times compounded: 10
results I was supposed to get: Interest earned: 406.03   Amount in savings: 13,186.03
results I got: Interest earned: 407.01    Amount: 13187

Program 2 Plan:
include cmath
create a cin int 'loan_amount'
create a cin double 'annual_rate' for annual interest rate as a percentage
create a cin for number of monthly payments 'number_of_payments'
turn the annual interest rate into monthly using a double variable by writing 'monthly_rate = annual_rate/100.0/1.0'
calculate monthly loan payment with:
create a double variable 'x defined by 'pow(monthly_rate*(1+monthly_rate),number_of_payments)'
create a double variable 'y' defined by 'pow(1+monthly_rate,number_of_payments)-1'
create a double variable 'monthly_payment' defined by '(x/y)*loan_amount'
create double variables to calculate 'amount_paid_back = monthly_payment*number_of_payments' 
and 'interest_paid = amount_paid_back−loan_amount'
in a cout display the loan amount, monthly interest rate, number of payments, monthly payment, 
amount paid back, and interest paid with text labels
run with given tests to make sure it works 

Second Program Test 1:
Loan amount: $10,000.00
Annual interest rate: 12%
Number of payments: 36
results I am supposed to get: Monthly Payment: $332.14 | Amount Paid Back: $11,957.15 | Interest Paid: $1,957.15
results I got: Monthly Payment: $278.292 | Amount Paid Back: $10018.5 | Interest Paid: $18.5108

Second Program Test 2:
Loan amount: $9,999.00
Annual interest rate: 11%
Number of payments: 35
results received: Monthly Payment: $286.157 | Amount Paid Back: $10015.5 | Interest Paid: $16.5069

Explain:
Why must a percentage be divided by 100 before using it in a formula?
Dividing any percentage by 100 turns it into a decimal
How does pow represent exponentiation?
pow(base,exponent);
What does the number of compounding periods change in the savings formula?
More compounds = more money paid
How is an annual interest rate converted to a monthly rate?
annual/12=monthly because of 12 months a year
Why should double be used for these calculations?
int rounds amounts with each calculation so the real value gets lost
Why should calculations use full precision when money is displayed to two decimal places?
if only one decimal place is used, the compiler rounds amounts and the real answer is lost in calculations
How are the amount paid back and total interest calculated?
amount_paid = monthly_payment * number_of_payments;
interest_paid = amount_paid_back - loan_amount;
Why are calculations stored in variables before being displayed?
changing a variable in a cout can cause compiler errors
*/