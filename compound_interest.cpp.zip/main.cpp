#include <iostream>
#include <cmath>

int main() {
    //cin variables:
    double principal;
    std::cin >> principal;
    double rate;
    std::cin >> rate;
    int times_compounded;
    std::cin >> times_compounded;
    //calculations:
    double amount = principal*pow(1.0+(rate/100)/times_compounded, times_compounded);
    double interest_earned = amount-principal;
    //.
    std::cout<<"Your interest rate is "<<rate<<"%. \nYour interest has compounded "<<times_compounded<<" times this year.\nYour principal balance is "<<principal
    <<" \nYour interest earned is $"<<interest_earned<<" \nYour final amount is "<<amount;
    return 0;
}