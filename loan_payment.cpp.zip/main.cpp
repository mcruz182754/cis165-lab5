#include <iostream>
#include <cmath>
int main() {
    //user inputs:
    double loan_amount;
    std::cin>>loan_amount;
    double annual_rate;
    std::cin>>annual_rate;
    int number_of_payments;
    std::cin>>number_of_payments;
    //annual rate % to decimal
    annual_rate/=100.00;
    //calculations:
    double monthly_rate = annual_rate/100.00/12.00;
    double x = pow(1 + monthly_rate, number_of_payments);
    double monthly_payment = (monthly_rate * x / (x - 1)) * loan_amount;
    double amount_paid_back = monthly_payment * number_of_payments;
    double interest_paid = amount_paid_back - loan_amount;
    //.
    std::cout<<"Your loan amount is $"<<loan_amount<<"\nYour monthly interest rate is "<<monthly_rate<<
    "%\nYour numbers of payments is "<<number_of_payments<<"\nYour payment per month is $"<<monthly_payment<<
    "\nThe amount you paid back is $"<<amount_paid_back<<"\nYour total interest paid is $"<<interest_paid;
    return 0;
}